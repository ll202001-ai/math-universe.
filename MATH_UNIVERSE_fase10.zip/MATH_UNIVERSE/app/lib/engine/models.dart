/// Respuesta del motor (contrato JSON 1.1). Solo lectura: ningun calculo matematico se hace en Dart.
class EngineResponse {
  EngineResponse(this.raw);

  final Map<String, dynamic> raw;

  /// Respuesta generada por el cliente (no por el motor): motor no disponible, plazo agotado, etc.
  factory EngineResponse.local(String status, String code, String message) => EngineResponse({
        'status': status,
        'api_version': 'cliente',
        'verification': {'status': 'not_performed', 'method': null},
        'conditions': <String>[],
        'warnings': <String>[],
        'error': {'code': code, 'message': message, 'details': <String, dynamic>{}},
        'local': true,
      });

  String get status => (raw['status'] ?? 'internal_error').toString();
  String? get exactResult => raw['exact_result']?.toString();
  String? get approximateResult => raw['approximate_result']?.toString();
  String? get method => raw['method']?.toString();
  List<String> get conditions => _strings(raw['conditions']);
  List<String> get warnings => _strings(raw['warnings']);
  Map<String, dynamic> get data => (raw['data'] is Map) ? Map<String, dynamic>.from(raw['data'] as Map) : <String, dynamic>{};
  String get verificationStatus => ((raw['verification'] is Map) ? (raw['verification'] as Map)['status'] : null)?.toString() ?? 'not_performed';
  String? get verificationMethod => ((raw['verification'] is Map) ? (raw['verification'] as Map)['method'] : null)?.toString();
  String? get errorCode => ((raw['error'] is Map) ? (raw['error'] as Map)['code'] : null)?.toString();
  String? get errorMessage => ((raw['error'] is Map) ? (raw['error'] as Map)['message'] : null)?.toString();
  double? get elapsedMs => (raw['elapsed_ms'] is num) ? (raw['elapsed_ms'] as num).toDouble() : null;

  /// Hay un resultado matematico que mostrar (exacto, familia de soluciones o conjunto vacio).
  bool get hasResult => const {'success_exact', 'success_approximate', 'multiple_solutions', 'no_solution'}.contains(status);

  /// Matriz de resultado (lista de filas de textos) si la respuesta la trae en data.matrix.
  List<List<String>>? get matrix {
    final m = data['matrix'];
    if (m is! List) return null;
    return m.map<List<String>>((r) => (r as List).map((e) => e.toString()).toList()).toList();
  }

  static List<String> _strings(dynamic v) => (v is List) ? v.map((e) => e.toString()).toList() : <String>[];
}

const matrixOperations = <String, String>{
  'matrix_add': 'Suma A + B',
  'matrix_sub': 'Resta A - B',
  'matrix_mul': 'Producto A x B',
  'matrix_transpose': 'Transpuesta',
  'matrix_det': 'Determinante',
  'matrix_inverse': 'Inversa',
  'matrix_rank': 'Rango',
  'matrix_rref': 'Forma escalonada reducida',
  'matrix_solve': 'Resolver A x = b',
};

const matrixOpsNeedingB = {'matrix_add', 'matrix_sub', 'matrix_mul', 'matrix_solve'};

const calculusOperations = <String, String>{
  'evaluate': 'Evaluar',
  'simplify': 'Simplificar',
  'expand': 'Expandir',
  'factor': 'Factorizar',
  'solve': 'Resolver ecuacion o sistema',
  'differentiate': 'Derivar',
  'integrate': 'Integrar',
  'limit': 'Limite',
};

/// "1 2 3\n4 5 6" (o con comas/punto y coma) -> [["1","2","3"],["4","5","6"]]. Lanza FormatException si no es rectangular.
List<List<String>> parseMatrixText(String text) {
  final rows = text
      .split(RegExp(r'[\n;]'))
      .map((l) => l.trim())
      .where((l) => l.isNotEmpty)
      .map((l) => l.split(RegExp(r'[\s,]+')).where((c) => c.isNotEmpty).toList())
      .toList();
  if (rows.isEmpty) throw const FormatException('La matriz esta vacia');
  final n = rows.first.length;
  if (rows.any((r) => r.length != n)) throw const FormatException('Todas las filas deben tener el mismo numero de columnas');
  return rows;
}
