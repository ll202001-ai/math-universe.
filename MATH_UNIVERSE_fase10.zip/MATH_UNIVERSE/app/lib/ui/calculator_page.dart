import 'package:flutter/material.dart';

import '../data/history_store.dart';
import '../engine/engine_client.dart';
import '../engine/models.dart';
import 'result_view.dart';

class CalculatorPage extends StatefulWidget {
  const CalculatorPage({super.key, required this.engine, required this.store, this.initialExpression, this.initialOperation});
  final EngineClient engine;
  final HistoryStore store;
  final String? initialExpression;
  final String? initialOperation;

  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  late final TextEditingController _expr = TextEditingController(text: widget.initialExpression ?? '');
  final TextEditingController _var = TextEditingController();
  final TextEditingController _point = TextEditingController(text: '0');
  late String _op = widget.initialOperation ?? 'evaluate';
  EngineResponse? _resp;
  bool _busy = false;

  @override
  void dispose() {
    _expr.dispose();
    _var.dispose();
    _point.dispose();
    super.dispose();
  }

  Future<void> _calculate() async {
    final text = _expr.text.trim();
    if (text.isEmpty) return;
    setState(() => _busy = true);
    final req = <String, dynamic>{'operation': _op, 'expression': text, 'timeout_ms': 10000};
    if (_var.text.trim().isNotEmpty) req['variables'] = [_var.text.trim()];
    if (_op == 'limit') req['point'] = _point.text.trim();
    final r = await widget.engine.send(req);
    await widget.store.add(HistoryEntry(
        createdAt: DateTime.now(),
        kind: 'calculo',
        operation: _op,
        input: text,
        result: r.exactResult ?? r.errorMessage ?? r.status,
        status: r.status));
    if (!mounted) return;
    setState(() {
      _resp = r;
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      DropdownButtonFormField<String>(
        key: const Key('selector_operacion'),
        initialValue: _op,
        decoration: const InputDecoration(labelText: 'Operacion', border: OutlineInputBorder()),
        items: [for (final e in calculusOperations.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
        onChanged: (v) => setState(() => _op = v ?? _op),
      ),
      const SizedBox(height: 12),
      TextField(
        key: const Key('campo_expresion'),
        controller: _expr,
        decoration: const InputDecoration(labelText: 'Expresion (ej.: (x^3-8)/(x-2))', border: OutlineInputBorder()),
        onSubmitted: (_) => _calculate(),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: TextField(controller: _var, decoration: const InputDecoration(labelText: 'Variable (opcional)', border: OutlineInputBorder()))),
        if (_op == 'limit') ...[
          const SizedBox(width: 12),
          Expanded(child: TextField(controller: _point, decoration: const InputDecoration(labelText: 'Punto (ej.: 0, 2, +oo)', border: OutlineInputBorder()))),
        ],
      ]),
      const SizedBox(height: 12),
      FilledButton.icon(
        key: const Key('boton_calcular'),
        onPressed: _busy ? null : _calculate,
        icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.calculate),
        label: const Text('Calcular'),
      ),
      const SizedBox(height: 16),
      if (_resp != null) ResultView(response: _resp!),
    ]);
  }
}
