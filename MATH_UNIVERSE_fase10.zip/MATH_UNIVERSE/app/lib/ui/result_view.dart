import 'package:flutter/material.dart';

import '../engine/models.dart';

/// Muestra una respuesta del motor sin reinterpretarla: resultado, condiciones, avisos y estado de verificacion.
class ResultView extends StatelessWidget {
  const ResultView({super.key, required this.response});
  final EngineResponse response;

  static String statusText(EngineResponse r) {
    switch (r.status) {
      case 'success_exact':
        return 'Resultado exacto';
      case 'success_approximate':
        return 'Resultado aproximado';
      case 'multiple_solutions':
        return 'Infinitas soluciones';
      case 'no_solution':
        return 'Sin solucion';
      case 'unsupported':
        return 'No soportado por el motor';
      case 'invalid_input':
        return 'Entrada no valida';
      case 'domain_error':
        return 'Error de dominio';
      case 'timeout':
        return 'Tiempo agotado';
      default:
        return 'Error interno';
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = response;
    final cs = Theme.of(context).colorScheme;
    final verified = r.verificationStatus == 'passed';
    final m = r.matrix;
    return Card(
      key: const Key('tarjeta_resultado'),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
            Chip(
                key: const Key('chip_estado'),
                label: Text(statusText(r)),
                backgroundColor: r.hasResult ? cs.primaryContainer : cs.errorContainer),
            Chip(
                key: const Key('chip_verificacion'),
                avatar: Icon(verified ? Icons.verified : Icons.help_outline, size: 18),
                label: Text(verified ? 'Verificado de forma independiente' : 'Sin verificacion independiente')),
          ]),
          const SizedBox(height: 8),
          if (r.exactResult != null && m == null)
            SelectableText(r.exactResult!, key: const Key('texto_resultado'), style: Theme.of(context).textTheme.headlineSmall),
          if (m != null) _MatrixTable(m),
          if (r.approximateResult != null) Padding(padding: const EdgeInsets.only(top: 6), child: SelectableText('Aproximado: ${r.approximateResult}')),
          if (r.data['kind'] == 'infinite' || r.data['kind'] == 'unique') _SolveDetails(r.data),
          if (r.conditions.isNotEmpty)
            Padding(padding: const EdgeInsets.only(top: 8), child: Text('Condiciones: ${r.conditions.join(', ')}')),
          for (final w in r.warnings) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Aviso: $w', style: TextStyle(color: cs.tertiary))),
          if (r.errorMessage != null)
            Padding(
                padding: const EdgeInsets.only(top: 8),
                child: SelectableText(r.errorMessage!, key: const Key('texto_error'), style: TextStyle(color: cs.error))),
          if (verified && r.verificationMethod != null)
            Padding(padding: const EdgeInsets.only(top: 8), child: Text('Metodo de verificacion: ${r.verificationMethod}', style: Theme.of(context).textTheme.bodySmall)),
          if (r.elapsedMs != null) Text('${r.elapsedMs!.toStringAsFixed(1)} ms', style: Theme.of(context).textTheme.bodySmall),
        ]),
      ),
    );
  }
}

class _MatrixTable extends StatelessWidget {
  const _MatrixTable(this.m);
  final List<List<String>> m;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Table(
        key: const Key('tabla_matriz'),
        defaultColumnWidth: const IntrinsicColumnWidth(),
        border: TableBorder.symmetric(inside: BorderSide(color: Theme.of(context).dividerColor)),
        children: [
          for (final row in m)
            TableRow(children: [for (final c in row) Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), child: SelectableText(c))])
        ],
      ),
    );
  }
}

class _SolveDetails extends StatelessWidget {
  const _SolveDetails(this.data);
  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    final basis = data['nullspace_basis'];
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Rango: ${data['rank']}'),
        if (data['particular'] is List) Text('Solucion particular: ${(data['particular'] as List).join(', ')}'),
        if (basis is List && basis.isNotEmpty)
          for (var i = 0; i < basis.length; i++) Text('Direccion libre t${i + 1}: ${(basis[i] as List).join(', ')}'),
      ]),
    );
  }
}
