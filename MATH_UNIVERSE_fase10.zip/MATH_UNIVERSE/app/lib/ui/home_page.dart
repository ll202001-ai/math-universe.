import 'package:flutter/material.dart';

import '../data/history_store.dart';
import '../engine/engine_client.dart';
import 'calculator_page.dart';
import 'history_page.dart';
import 'matrix_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.engine, required this.store, this.storeWarning});
  final EngineClient engine;
  final HistoryStore store;
  final String? storeWarning;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _tab = 0;
  String? _engineLine;
  Key _calcKey = UniqueKey();
  Key _histKey = UniqueKey();
  String? _reuseExpr;
  String? _reuseOp;

  @override
  void initState() {
    super.initState();
    _checkEngine();
  }

  Future<void> _checkEngine() async {
    final r = await widget.engine.send({'operation': 'ping'}, timeout: const Duration(seconds: 15));
    if (!mounted) return;
    setState(() => _engineLine = r.status == 'success_exact' ? 'Motor local listo' : 'Motor no disponible: ${r.errorMessage ?? r.status}');
  }

  @override
  void dispose() {
    widget.engine.dispose();
    widget.store.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      CalculatorPage(key: _calcKey, engine: widget.engine, store: widget.store, initialExpression: _reuseExpr, initialOperation: _reuseOp),
      MatrixPage(engine: widget.engine, store: widget.store),
      HistoryPage(
          key: _histKey,
          store: widget.store,
          onReuse: (e) {
            if (e.kind == 'calculo') {
              setState(() {
                _reuseExpr = e.input;
                _reuseOp = calculusKnown(e.operation) ? e.operation : 'evaluate';
                _calcKey = UniqueKey();
                _tab = 0;
              });
            }
          }),
    ];
    final ok = _engineLine == null || _engineLine!.startsWith('Motor local listo');
    return Scaffold(
      appBar: AppBar(title: const Text('MATH UNIVERSE'), bottom: PreferredSize(
          preferredSize: const Size.fromHeight(22),
          child: Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(_engineLine ?? 'Iniciando motor...', key: const Key('estado_motor'), style: TextStyle(color: ok ? null : Theme.of(context).colorScheme.error))))),
      body: Column(children: [
        if (widget.storeWarning != null) MaterialBanner(content: Text(widget.storeWarning!), actions: const [SizedBox()]),
        Expanded(child: IndexedStack(index: _tab, children: pages)),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() {
          _tab = i;
          if (i == 2) _histKey = UniqueKey(); // recarga el historial al entrar
        }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.functions), label: 'Calculadora'),
          NavigationDestination(icon: Icon(Icons.grid_on), label: 'Matrices'),
          NavigationDestination(icon: Icon(Icons.history), label: 'Historial'),
        ],
      ),
    );
  }
}

bool calculusKnown(String op) => const {'evaluate', 'simplify', 'expand', 'factor', 'solve', 'differentiate', 'integrate', 'limit'}.contains(op);
