import 'package:flutter/material.dart';

import 'data/history_store.dart';
import 'engine/engine_client.dart';
import 'engine/engine_factory.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final EngineClient engine = createEngineClient();
  HistoryStore store;
  String? storeWarning;
  try {
    store = await SqliteHistoryStore.open();
  } catch (e) {
    store = MemoryHistoryStore();
    storeWarning = 'No se pudo abrir el historial en disco ($e). El historial de esta sesion no se guardara.';
  }
  runApp(MathUniverseApp(engine: engine, store: store, storeWarning: storeWarning));
}

class MathUniverseApp extends StatelessWidget {
  const MathUniverseApp({super.key, required this.engine, required this.store, this.storeWarning});

  final EngineClient engine;
  final HistoryStore store;
  final String? storeWarning;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MATH UNIVERSE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFF1B5E8C), useMaterial3: true),
      darkTheme: ThemeData(colorSchemeSeed: const Color(0xFF1B5E8C), brightness: Brightness.dark, useMaterial3: true),
      home: HomePage(engine: engine, store: store, storeWarning: storeWarning),
    );
  }
}
