# Empaqueta MATH UNIVERSE para Windows: app Flutter + Python embebido + motor + jsonschema, prueba el motor empaquetado y crea el instalador.
# Se ejecuta en GitHub Actions (windows-latest). No requiere intervencion del usuario.
param([string]$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path)
$ErrorActionPreference = "Stop"
$PyVer = "3.12.8"
$rel = Join-Path $Root "app\build\windows\x64\runner\Release"
if (-not (Test-Path (Join-Path $rel "math_universe_app.exe"))) { throw "No se encontro la app compilada en $rel" }

$rt = Join-Path $rel "engine_runtime"
if (Test-Path $rt) { Remove-Item $rt -Recurse -Force }
New-Item -ItemType Directory -Force (Join-Path $rt "python") | Out-Null

# 1) Python embebido oficial
$zip = Join-Path $env:RUNNER_TEMP "python-embed.zip"
Invoke-WebRequest "https://www.python.org/ftp/python/$PyVer/python-$PyVer-embed-amd64.zip" -OutFile $zip
Expand-Archive $zip -DestinationPath (Join-Path $rt "python") -Force
$pth = Get-ChildItem (Join-Path $rt "python") -Filter "python*._pth" | Select-Object -First 1
$zipName = ($pth.BaseName -replace "_pth$","") + ".zip"
[IO.File]::WriteAllText($pth.FullName, "$zipName`r`n.`r`n..\site-packages`r`n")

# 2) jsonschema (validacion de contrato) para ese Python, solo wheels binarios oficiales
python -m pip install --quiet --target (Join-Path $rt "site-packages") --platform win_amd64 --python-version 3.12 --only-binary=:all: --implementation cp jsonschema
if ($LASTEXITCODE -ne 0) { throw "No se pudo instalar jsonschema para el Python embebido" }

# 3) motor (sin pruebas, auditoria ni herramientas)
$eng = Join-Path $rt "engine"
New-Item -ItemType Directory -Force $eng | Out-Null
foreach ($d in "math_universe_engine","math_universe_linalg","schema") { Copy-Item (Join-Path $Root "engine\$d") (Join-Path $eng $d) -Recurse }
Copy-Item (Join-Path $Root "engine\run_server.py") $eng
Get-ChildItem $eng -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force

# 4) prueba del motor EMPAQUETADO (Python embebido, sin instalar nada)
$py = Join-Path $rt "python\python.exe"
$js = & $py -c "import jsonschema; print(jsonschema.__version__)"
if ($LASTEXITCODE -ne 0) { throw "jsonschema no se importa en el Python embebido" }
Write-Host "jsonschema $js en el Python embebido"
$reqs = @(
 '{"operation":"ping","request_id":1}',
 '{"operation":"matrix_det","request_id":2,"structured_input":{"a":[[1,2],[3,4]]}}',
 '{"operation":"matrix_inverse","request_id":3,"structured_input":{"a":[[2,1],[1,1]]}}',
 '{"operation":"simplify","request_id":4,"expression":"(x^3-8)/(x-2)"}',
 '{"operation":"evaluate","request_id":5,"expression":"1e999999999","timeout_ms":2000}'
)
$OutputEncoding = [Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$out = ($reqs -join "`n") | & $py -X utf8 (Join-Path $eng "run_server.py")
if ($LASTEXITCODE -ne 0) { throw "El motor empaquetado termino con error" }
$lines = @($out)
if ($lines.Count -ne 5) { throw "Se esperaban 5 respuestas y llegaron $($lines.Count)" }
$r = $lines | ForEach-Object { $_ | ConvertFrom-Json }
if ($r[0].status -ne "success_exact") { throw "ping fallo" }
if ($r[1].exact_result -ne "-2" -or $r[1].verification.status -ne "passed") { throw "determinante fallo" }
if ($r[2].exact_result -ne "[[1, -1], [-1, 2]]") { throw "inversa fallo: $($r[2].exact_result)" }
if ($r[3].api_version -ne "1.1") { throw "api_version inesperada" }
if ($r[4].status -ne "invalid_input") { throw "H-1: el literal gigante no fue rechazado" }
Write-Host "Motor empaquetado: 5/5 respuestas correctas"

# 5) instalador (Inno Setup) y version portable
$dist = Join-Path $Root "dist"
New-Item -ItemType Directory -Force $dist | Out-Null
choco install innosetup -y --no-progress | Out-Null
$iscc = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if (-not (Test-Path $iscc)) { throw "No se encontro Inno Setup" }
& $iscc "/O$dist" (Join-Path $Root "installer\MathUniverse.iss")
if ($LASTEXITCODE -ne 0) { throw "Fallo la creacion del instalador" }
Compress-Archive -Path (Join-Path $rel "*") -DestinationPath (Join-Path $dist "MATH_UNIVERSE_portable_windows.zip") -Force
Get-ChildItem $dist | ForEach-Object { "{0}  {1}" -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.ToLower(), $_.Name } | Set-Content (Join-Path $dist "SHA256_DE_LA_COMPILACION.txt")
Get-ChildItem $dist
