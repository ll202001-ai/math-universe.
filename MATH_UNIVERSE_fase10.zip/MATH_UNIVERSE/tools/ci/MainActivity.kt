package com.mathuniverse.math_universe_app

import android.os.Handler
import android.os.Looper
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "math_universe/engine").setMethodCallHandler { call, result ->
            if (call.method == "handle") {
                val line = call.arguments as String
                executor.execute {
                    try {
                        val out = Python.getInstance().getModule("mu_bridge").callAttr("handle", line).toString()
                        main.post { result.success(out) }
                    } catch (e: Exception) {
                        main.post { result.error("ENGINE", e.message, null) }
                    }
                }
            } else {
                result.notImplemented()
            }
        }
    }
}
