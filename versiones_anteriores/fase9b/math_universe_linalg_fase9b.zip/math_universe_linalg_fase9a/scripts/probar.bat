@echo off
rem Pruebas del modulo de algebra lineal AISLADO. Uso: scripts\probar.bat [ruta\a\carpeta\engine]
chcp 65001 > nul
set PYTHONUTF8=1
cd /d "%~dp0.."
if not "%~1"=="" set MATH_UNIVERSE_ENGINE_PATH=%~1
python -m pip install --quiet pytest numpy
if errorlevel 1 (echo [ERROR] No se pudo instalar pytest/numpy ^(numpy solo lo usan las pruebas^) & exit /b 1)
python -c "import sys,numpy,pytest; print('Python',sys.version.split()[0]); print('NumPy',numpy.__version__); print('pytest',pytest.__version__)"
python tools\manifiesto.py
python -m pytest tests -q -p no:cacheprovider
exit /b %ERRORLEVEL%
