# MATH UNIVERSE · módulo de álgebra lineal (AISLADO) · v0.1.1-aislado

Componente **independiente** del motor estable (fase 8). **No lo modifica ni se registra en él**: no toca el contrato JSON, el dispatcher ni las operaciones existentes.

## Instalación y pruebas
1. Descomprima la fase 8 (`math_universe_fase8.zip`) en una carpeta llamada `math_universe`, **al lado** de esta carpeta (o defina `MATH_UNIVERSE_ENGINE_PATH` con la ruta a `math_universe\\engine`).
2. Windows: `scripts\\probar.bat` (instala `pytest` y `numpy`, **solo para las pruebas**; el módulo no los necesita). Cualquier SO: `python -m pip install pytest numpy` y `python -m pytest tests -q`.
3. Integridad del paquete: `python tools/manifiesto.py`.

## Uso
```python
import math_universe_linalg as L
r = L.run("matrix_inverse", "[[2,1],[1,1]]")
r["status"], r["exact_result"], r["verification"]
# success_exact  [[1, -1], [-1, 2]]  {'status': 'passed', 'method': 'A·A⁻¹ = I y A⁻¹·A = I (exacto)'}
```
Operaciones: `matrix_add, matrix_sub, matrix_mul, matrix_transpose, matrix_det, matrix_inverse, matrix_rank, matrix_rref, matrix_solve`.
Entradas: texto `[[1,1/2],[0.25,(1+2)/6]]` o listas; entradas = racionales exactos (enteros, fracciones, decimales, constantes racionales).

Ver `docs/INFORME_ALGEBRA_LINEAL.md` (resultados y límites) y `docs/ARCHIVOS_NUEVOS_Y_REUTILIZADOS.md`.
