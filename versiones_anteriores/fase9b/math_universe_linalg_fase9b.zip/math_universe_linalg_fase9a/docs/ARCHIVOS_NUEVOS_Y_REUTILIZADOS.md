# Archivos nuevos y componentes reutilizados

## Archivos NUEVOS (todos en este paquete; ninguno está en el motor estable)
| Archivo | Líneas | Función |
|---|---|---|
| `math_universe_linalg/__init__.py` | 8 | API pública |
| `math_universe_linalg/_motor.py` | 31 | Localiza el motor fase 8 (solo añade su ruta al final de `sys.path`) |
| `math_universe_linalg/matrix.py` | 123 | `Matrix` exacta sobre Q, lectura segura de entradas y de `[[...],[...]]` |
| `math_universe_linalg/ops.py` | 110 | add, sub, mul, transpose, det, inverse, rank, rref, solve |
| `math_universe_linalg/checks.py` | 89 | Verificadores independientes (Bareiss, Laplace, Freivalds, certificados) |
| `math_universe_linalg/api.py` | 111 | `run(operation, a, b)` → respuesta con `status/exact_result/data/verification` |
| `tests/` (13 archivos, 279 pruebas) | — | `conftest` + `test_00` … `test_31` (ver informe) |
| `tools/manifiesto.py`, `scripts/probar.bat` | — | Manifiesto SHA-256 y ejecución en Windows (el `.bat` **no se ha ejecutado en Windows**) |
| `docs/*`, `README.md`, `MANIFIESTO_SHA256.txt` | — | Documentación y manifiesto |

## Componentes del motor estable REUTILIZADOS (solo importados, ninguno modificado)
| Componente | Para qué se usa | ¿Es técnicamente correcto reutilizarlo? |
|---|---|---|
| `solve.rref` | Gauss-Jordan exacto: rref, rango, inversa (`[A\|I]`), sistemas (`[A\|b\|I]`) | Sí: opera con `Fraction`, ya probada (sistemas del oráculo); se envuelve sin alterarla. Se probó además con propiedades (unicidad, idempotencia) |
| `parser.parse` + `ast_tools.normalize/const_value` | Entradas como `(1+2)/6`, `2*3` (constantes racionales) | Sí, **con una protección propia** (ver hallazgo H-1): se filtran literales gigantes antes de delegar |
| `errors.*` (`InvalidRequest`, `MathDomainError`, `NotImplementedOperation`, `VerificationFailed`…) | Mismos códigos de error que el motor | Sí |
| `limits.start/check/stop` | Plazo cooperativo (`timeout_ms`) en bucles largos | Sí; el módulo llama a `start/stop` solo en su propio `run` |

**No reutilizados (a propósito):** `dispatcher`, `schema/*`, `server`, `symbolic` (SymPy), `calculus`, `poly`, `rational`. `Q(√d)` (`qsqrt`) queda para autovalores, etapa posterior.
**Dependencias:** ninguna obligatoria fuera de la biblioteca estándar y el motor. `numpy` y `pytest` solo para pruebas.
