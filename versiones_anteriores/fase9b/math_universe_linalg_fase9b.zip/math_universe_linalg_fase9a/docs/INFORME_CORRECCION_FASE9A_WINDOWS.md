# Informe · corrección de 2 fallos de FASE 9A en Windows (v0.1.1-aislado)

Resultado original en Windows: **275 aprobadas, 2 fallidas** (se conserva). Causa: **ambas son falsos positivos de las pruebas de aislamiento**; no hay defecto matemático ni del módulo ni del motor, y el motor de la fase 8 no se modificó.
Nota: no puedo ver tu carpeta de Windows; el diagnóstico se apoya en el código de las pruebas y en haber **reproducido aquí** exactamente 275/2 con las pruebas antiguas (ver §3).

## 1. Fallo 1 · `test_no_se_ha_escrito_en_la_carpeta_del_motor`
- **Qué hacía:** `os.walk(<motor>/engine)` y fallaba si cualquier archivo se llamaba `*linalg*` o `*matrix*`.
- **Causa raíz:** recorría **todo** `engine/`, incluido `engine/.venv` (entorno virtual creado en Windows). NumPy trae archivos legítimos con esos nombres (`numpy/linalg/…`, `numpy/matrixlib/…`, `defmatrix.py`) y el módulo también puede estar descomprimido bajo esa carpeta. El nombre del archivo no prueba que el módulo escribiera nada.
- **Veredicto:** falso positivo (criterio demasiado amplio y sin excluir dependencias).
- **Corrección (no se debilita, se hace más estricta y más precisa):**
  1. `test_usar_el_modulo_no_escribe_ni_cambia_nada_en_la_carpeta_del_motor` (nueva): instantánea SHA-256 de todo el código del motor (sin `.venv`, cachés ni los archivos del propio módulo) **antes y después** de ejecutar las operaciones; deben ser idénticas. Esto detecta escrituras reales, que el criterio por nombre no detectaba.
  2. `test_el_motor_no_contiene_archivos_de_algebra_lineal_ajenos_a_el`: la búsqueda por nombre se limita a `engine/math_universe_engine/` (el paquete del motor) y a `.py`.
  3. Se mantiene sin cambios `test_el_motor_estable_esta_intacto_segun_su_manifiesto_sha256` (hash de cada archivo del motor).

## 2. Fallo 2 · `test_open_con_encoding_y_sin_modulos_unix`
- **Qué hacía:** `os.walk(RAIZ)` sobre toda la carpeta del paquete, buscando `open(` sin `encoding` e `import fcntl/pwd/...`.
- **Causa raíz:** no excluía `.venv`; al haber un entorno virtual dentro del árbol analizado, inspeccionaba código de **NumPy y jsonschema** (que usan `open` sin encoding en modo binario/texto y módulos específicos de Unix con guardas). Ese código no es del módulo.
- **Veredicto:** falso positivo (alcance incorrecto).
- **Corrección:** solo se analizan las carpetas propias `math_universe_linalg/`, `tests/` y `tools/`, con una función común `recorrer()` (en `conftest.py`) que no entra en `.venv`, `venv`, `site-packages`, `__pycache__`, `.git`, `*.egg-info` ni en carpetas con `pyvenv.cfg`. Prueba nueva `test_el_alcance_excluye_entornos_virtuales` que demuestra que un `.venv` con código «malo» se ignora.
- `tools/manifiesto.py` ya excluía `.venv`; no cambió.

## 3. Evidencia (Linux, Python 3.13.18; escenarios reproducidos)
| Escenario | Pruebas antiguas | Pruebas corregidas |
|---|---|---|
| `engine/.venv` con archivos tipo NumPy (`matrixlib`, `linalg`) | 1 fallo (fallo 1) | 279 aprobadas |
| `.venv` dentro del árbol del módulo con `import fcntl`/`open('x')` | 2 fallos (275/2, igual que en Windows) | 279 aprobadas |
| Módulo descomprimido dentro de `engine/` | 1 fallo | 279 aprobadas |
| **Intrusión real:** `matrix_x.py` dentro de `engine/math_universe_engine/` | — | **falla** (la prueba sigue detectando) |
| **Defecto real:** `open('f')` sin encoding en el módulo | — | **falla** (el lint sigue detectando) |
Sin escenario especial: 279 aprobadas, 0 falladas, 0 omitidas.

## 4. Conteo
Antes 277; ahora **279** = 277 originales (2 reescritas, sin eliminar ninguna) + 2 nuevas (`test_el_alcance_excluye_entornos_virtuales`, `test_usar_el_modulo_no_escribe…`; la prueba 1 se dividió en dos). No se desactivó ni omitió ninguna.

## 5. Pendiente
Confirmar en tu Windows que dan 279/0. Recomendación (no obligatoria): no crear `.venv` dentro de `engine/` ni descomprimir el módulo dentro de él; deja el módulo **junto** a `math_universe`.
