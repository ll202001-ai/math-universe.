# Informe · módulo de álgebra lineal aislado (v0.1.1-aislado)

Entorno de desarrollo: Linux, Python 3.13.18, NumPy 2.5.3, pytest 9.1.1. Motor estable: fase 8 (sin cambios; hash verificado por la prueba `test_00`).
**No ejecutado en Windows. No integrado en el motor.** Todo lo que sigue es evidencia de este entorno.

## 1. Resultado de las pruebas
**279 aprobadas · 0 falladas · 0 omitidas** (v0.1.1; ver INFORME_CORRECCION_FASE9A_WINDOWS.md; v0.1.0 daba 277 y en Windows 275/2 por falsos positivos) (≈ 2.3 s).
| Archivo | Pruebas | Qué cubre |
|---|---|---|
| test_00_aislamiento | 5 | motor fase 8 intacto (SHA-256 de sus archivos contra su manifiesto), NumPy/SciPy/SymPy **no** se importan, el dispatcher no conoce `matrix_*`, nada escrito en la carpeta del motor |
| test_10_suma_resta | 24 | valores conocidos; conmutativa/asociativa/neutro; errores de dimensión; **NumPy** |
| test_11_producto | 26 | valores conocidos; asociativa, distributiva, (AB)ᵀ=BᵀAᵀ; no cuadradas; **NumPy** exacto en enteros y con tolerancia en fracciones |
| test_12_transpuesta | 18 | conocida, involución, linealidad; **NumPy** |
| test_13_determinante | 34 | 2×2/3×3 clásicos; triangular; **Vandermonde (fórmula cerrada)**; **Hilbert (valores publicados)**; det(AB)=det A·det B, cambio de signo, escalado, filas iguales; tres algoritmos coinciden; **NumPy** |
| test_14_inversa | 26 | fórmula 2×2; **Hilbert 3×3 (inversa entera publicada)**; singular con certificado A·v=0; (AB)⁻¹=B⁻¹A⁻¹, (A⁻¹)⁻¹=A, det(A⁻¹)=1/det A; **NumPy** |
| test_15_rango | 43 | casos conocidos; **verdad de terreno por construcción** (A=B·C de rango r exacto); propiedades; **NumPy** |
| test_16_rref | 23 | conocida; unicidad (rref(PA)=rref(A)), idempotencia; rango vs **NumPy** |
| test_17_sistemas | 38 | única / infinitas (toda la recta x₀+t·v) / sin solución con certificado de Farkas; sobre- y subdeterminados; b=A·x₀ por construcción; **NumPy** (`solve` y `lstsq`) |
| test_20_verificadores_negativos | 7 | los verificadores **rechazan** resultados falsos; si se sabotea el algoritmo principal → `VERIFICATION_FAILED` y el candidato falso no se entrega |
| test_21_entradas_y_limites | 25 | formatos de entrada; entradas inválidas/hostiles; dimensión máx. 40; plazo cooperativo; matriz 20×20 exacta; JSON serializable |
| test_30_fuzz_contra_numpy | 8 | 5 semillas × 120 matrices (enteras y fraccionarias) y 3 semillas × 150 rectangulares: todas las operaciones verifican **y** coinciden con NumPy; los casos mal condicionados se cuentan (se exige un mínimo, no se omiten en silencio) |
| test_31_windows_lint | 2 | `open` con encoding, sin módulos solo-Unix |

## 2. Cómo se verifica cada operación (independiente del algoritmo principal)
| Operación | Algoritmo principal | Verificación independiente |
|---|---|---|
| suma / resta | elemento a elemento | (A+B)−B = A / (A−B)+B = A |
| producto | filas × columnas | **Freivalds exacto**: (AB)v = A(Bv) con 6 vectores racionales |
| transpuesta | zip | Tᵢⱼ = Aⱼᵢ índice a índice |
| determinante | eliminación gaussiana con Fraction | **Bareiss** + **Laplace** (n ≤ 6) + det(Aᵀ)=det(A) |
| inversa | `rref([A\|I])` del motor | A·A⁻¹ = I y A⁻¹·A = I exactos. Singular: certificado v≠0 con A·v=0, **comprobado antes de afirmarlo** |
| rango | `rref` del motor | rango ≥ r: menor r×r no nulo (Bareiss); rango ≤ r: n−r vectores independientes con A·v=0 |
| rref | `rref` del motor | forma reducida válida (pivotes 1, ceros en columna, orden) + rango consistente |
| sistemas | `rref([A\|b\|I])` | A·x_p=b y A·v=0 (base del núcleo); sin solución: **certificado de Farkas** yᵀA=0, yᵀb≠0 |

## 3. Rendimiento (matrices enteras aleatorias, aritmética exacta)
| n | det | inversa | rango |
|---|---|---|---|
| 20 | 0.01 s | 0.04 s | 0.02 s |
| 40 | 0.10 s | 0.42 s | 0.19 s |
(Medido aquí; no medido en Windows ni Android.)

## 4. Hallazgos
**H-1 · Defecto del motor ESTABLE (no corregido por la condición «no modificar»).** El parser/evaluador acepta literales numéricos sin cota:
- `evaluate "1e999999999"` **se cuelga más de 4 s ignorando `timeout_ms=2000`** (el plazo cooperativo no actúa dentro del parser) → posible denegación de servicio en la app;
- `evaluate "1e100000"` y `"1e20000"` devuelven `internal_error` en vez de un error de límite limpio.
Reproducir: `from math_universe_engine.dispatcher import handle; handle({"operation":"evaluate","expression":"1e999999999","timeout_ms":2000})`.
Mitigación en este módulo: filtro previo (`entry`) que rechaza exponentes de 3+ cifras y números de más de 60 dígitos; prueba `test_entradas_hostiles_no_cuelgan_ni_superan_el_plazo`. **Propuesta para la rama principal:** acotar el exponente y los dígitos del literal en el parser, con prueba de regresión.
**H-2 · Aviso de diseño.** `matrix_solve` con infinitas soluciones usa el estado `multiple_solutions` y `matrix_inverse` singular usa `domain_error` (coherente con el motor), pero esto no está validado contra el esquema de respuesta 1.0 (no se integró).

## 5. Límites (declarados)
- Solo entradas **racionales exactas** (sin símbolos, parámetros ni irracionales como √2). Con ellos el módulo responde `invalid_input`, no un resultado.
- Dimensión máxima 40×40. Sin autovalores/autovectores, descomposiciones (LU, QR), potencias ni normas.
- NumPy como oráculo es **de coma flotante**: se compara con tolerancia y sin matrices mal condicionadas (cond > 1e8, contadas); la evidencia exacta viene de los verificadores internos y de las pruebas de verdad de terreno por construcción.
- Pendiente de validación: ejecución en Windows (`scripts\probar.bat`), integración con contrato 1.1/dispatcher, Android.

## 6. Estado (tres categorías)
| Comprobado (aquí) | Pendiente de validación | Con limitaciones |
|---|---|---|
| 9 operaciones; 277 pruebas; motor intacto por hash; verificadores no vacuos; fuzz vs NumPy | Windows; integración; contrato 1.1; Android | Solo racionales; ≤ 40×40; sin autovalores; H-1 en el motor estable |
