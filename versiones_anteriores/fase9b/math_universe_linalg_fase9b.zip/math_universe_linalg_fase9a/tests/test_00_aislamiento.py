"""El módulo es AISLADO: el motor estable (fase 8) queda intacto, sin NumPy obligatorio y sin tocar contrato/dispatcher."""
import hashlib, os, subprocess, sys
import pytest
from conftest import RAIZ, recorrer
from math_universe_linalg import _motor


def _raiz_motor():
    p = _motor.ruta_motor() or os.path.dirname(os.path.abspath(__import__("math_universe_engine").__file__))
    return os.path.dirname(p) if os.path.basename(p) == "engine" else os.path.dirname(os.path.dirname(p))


def test_el_motor_estable_esta_intacto_segun_su_manifiesto_sha256():
    raiz = _raiz_motor(); man = os.path.join(raiz, "MANIFIESTO_SHA256.txt")
    if not os.path.isfile(man): pytest.skip(f"No hay manifiesto del motor en {raiz}; no se puede comprobar la integridad (OMITIDA, no aprobada)")
    mal, n = [], 0
    for l in open(man, encoding="utf-8"):
        if not l.strip(): continue
        h, rel = l.rstrip("\n").split("  ", 1)
        if not rel.startswith("engine/") or "__pycache__" in rel: continue
        p = os.path.join(raiz, rel)
        n += 1
        if not os.path.isfile(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h: mal.append(rel)
    assert n > 30 and not mal, mal


def test_numpy_no_es_dependencia_del_modulo():
    code = ("import sys; sys.path.insert(0, %r); import math_universe_linalg as L; "
            "L.run('matrix_det', '[[1,2],[3,4]]'); print('numpy' in sys.modules, 'scipy' in sys.modules, 'sympy' in sys.modules)" % RAIZ)
    out = subprocess.run([sys.executable, "-I", "-c", code], capture_output=True, text=True, env={**os.environ, "PYTHONPATH": ""}, timeout=60)
    assert out.returncode == 0, out.stderr
    assert out.stdout.split() == ["False", "False", "False"], out.stdout


def test_el_contrato_y_el_dispatcher_no_conocen_las_operaciones_de_matrices():
    from math_universe_engine import dispatcher
    from math_universe_engine.dispatcher import handle
    assert not any("matrix" in k for k in dispatcher.OPS)
    r = handle({"operation": "determinant", "expression": "[[1,2],[3,4]]"})
    assert r["status"] == "unsupported"                      # el motor estable sigue sin saber de matrices (integración = otra etapa)


def _snapshot_motor():
    """(ruta relativa -> sha256) del CÓDIGO del motor (engine/math_universe_engine). Sin .venv, dependencias ni cachés
    y sin los archivos de este módulo, aunque el usuario lo haya descomprimido dentro de la carpeta del motor."""
    base = os.path.join(_raiz_motor(), "engine")
    propio = os.path.abspath(RAIZ)
    out = {}
    for r, ds, fs in recorrer(base):
        ds[:] = [d for d in ds if os.path.abspath(os.path.join(r, d)) != propio and d != "math_universe_linalg"]
        for f in fs:
            if f.endswith(".pyc"): continue
            p = os.path.join(r, f)
            with open(p, "rb") as h: out[os.path.relpath(p, base).replace(os.sep, "/")] = hashlib.sha256(h.read()).hexdigest()
    return out


def test_usar_el_modulo_no_escribe_ni_cambia_nada_en_la_carpeta_del_motor():
    antes = _snapshot_motor()
    import math_universe_linalg as L
    for op, a, b in (("matrix_add", "[[1,2],[3,4]]", "[[1,0],[0,1]]"), ("matrix_mul", "[[1,2],[3,4]]", "[[1,0],[0,1]]"),
                     ("matrix_det", "[[1,2],[3,4]]", None), ("matrix_inverse", "[[1,2],[3,4]]", None),
                     ("matrix_rank", "[[1,2],[2,4]]", None), ("matrix_solve", "[[1,2],[3,4]]", "[[5],[6]]")):
        assert L.run(op, a, b)["status"] in ("success_exact", "domain_error"), op
    despues = _snapshot_motor()
    assert antes == despues, sorted(set(antes) ^ set(despues) | {k for k in antes if k in despues and antes[k] != despues[k]})
    assert antes, "no se encontró código del motor que vigilar"


def test_el_motor_no_contiene_archivos_de_algebra_lineal_ajenos_a_el():
    """Solo se mira el paquete del motor (math_universe_engine), no .venv ni dependencias (NumPy tiene 'matrixlib', etc.)."""
    raiz = _raiz_motor()
    pk = os.path.join(raiz, "engine", "math_universe_engine")
    nuevos = [os.path.relpath(os.path.join(r, f), pk) for r, _, fs in recorrer(pk) for f in fs
              if ("linalg" in f.lower() or "matrix" in f.lower()) and f.endswith(".py")]
    assert not nuevos, nuevos
