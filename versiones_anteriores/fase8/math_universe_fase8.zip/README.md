# MATH UNIVERSE · motor matemático (fase de validación, sin interfaz)

`engine/math_universe_engine` (código) · `engine/tests` (pruebas) · `engine/audit` (oráculo independiente, pruebas aleatorias, comparador con SymPy) ·
`engine/tools/validar_todo.py` (validación completa) · `engine/schema` (contrato) · `docs/` (contrato, funciones, auditoría, errores, Windows, arquitectura).

Empiece por `docs/WINDOWS.md` (ejecutar la validación) y `docs/FUNCIONES.md` (qué hace, qué está probado y qué falta).
No incluye Flutter, APK ni instaladores ni álgebra lineal (siguiente módulo, no iniciado).

**Estado de la validación (comprobado / pendiente / limitaciones): `docs/ESTADO_VALIDACION.md`.** Integridad del paquete: `engine/tools/verificar_paquete.py`.
