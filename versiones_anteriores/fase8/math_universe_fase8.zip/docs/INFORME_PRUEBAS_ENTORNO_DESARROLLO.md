# INFORME DE PRUEBAS · MATH UNIVERSE motor
Fecha: 2026-11-24T13:28:09 · Python 3.13.18 · Linux-6.18.44-fc-v819-x86_64-with-glibc2.39
SymPy: NO instalado

**Aprobadas: 414 · Falladas: 0 · Omitidas: 1** (las omitidas NO se cuentan como aprobadas)

| Archivo | Aprobadas | Falladas | Omitidas |
|---|---|---|---|
| test_08_sympy.py | 0 | 0 | 1 |
| test_01_exactas.py | 30 | 0 | 0 |
| test_02_simbolicas.py | 60 | 0 | 0 |
| test_03_dominio.py | 27 | 0 | 0 |
| test_04_ecuaciones_sistemas.py | 38 | 0 | 0 |
| test_05_entradas_y_aproximacion.py | 30 | 0 | 0 |
| test_06_seguridad_y_recursos.py | 32 | 0 | 0 |
| test_07_verificacion_negativa.py | 8 | 0 | 0 |
| test_09_auditoria.py | 68 | 0 | 0 |
| test_10_comparador.py | 22 | 0 | 0 |
| test_11_respaldo_simulado.py | 6 | 0 | 0 |
| test_12_no_soportado.py | 46 | 0 | 0 |
| test_13_windows_lint.py | 3 | 0 | 0 |
| test_14_hallazgos_windows.py | 44 | 0 | 0 |

## Pruebas omitidas (requieren un entorno que aquí no existe)
- `tests/test_08_sympy.py [MÓDULO COMPLETO]` — Skipped: SymPy no está instalado en este entorno
